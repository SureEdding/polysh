#!/usr/bin/env python

from polysh.main import main
main()
